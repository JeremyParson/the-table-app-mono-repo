"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const headers_1 = __importDefault(require("../middleware/headers"));
const models_1 = require("../models");
const campaigns = (0, express_1.Router)();
campaigns.get("/", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const campaigns = yield models_1.Campaign.find({ public: true });
        res.json(campaigns);
    }
    catch (error) {
        res.status(500).json({ error: "The server ran into an error" });
    }
}));
campaigns.get("/:id", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const campaign = yield models_1.Campaign.findById(req.params.id)
            .populate("characters")
            .populate("handouts");
        res.status(200).json(campaign);
    }
    catch (error) {
        res.status(500).json({ error: "Server ran into an error" });
    }
}));
campaigns.use((req, res, next) => {
    if (!req.currentUser) {
        res.status(400).json({ error: "You must be logged in" });
        return;
    }
    next();
});
campaigns.get("/:id/join", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const campaign = yield models_1.Campaign.findById(req.params.id);
        const players = campaign.players;
        for (let id of players) {
            if (id.equals(req.currentUser._id))
                return res.status(400);
        }
        players.push(req.currentUser._id);
        campaign.update({ players });
        campaign.save();
        res.status(200).json(campaign);
    }
    catch (error) {
        res.status(500).json({ error: "Join failed" });
        console.log(error.message);
    }
}));
campaigns.post("/", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        let campaign = yield models_1.Campaign.create(Object.assign(Object.assign({}, req.body), { creator: req.currentUser._id, players: [req.currentUser._id] }));
        res.status(201).json(campaign);
    }
    catch (error) {
        res.status(500).json({ error: "The server ran into an error" });
    }
}));
campaigns.use("/:id", (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    const campaign = yield models_1.Campaign.findById(req.params.id);
    if (!campaign || (!req.currentUser._id.equals(campaign.creator) && req.currentUser.role != 'admin')) {
        res.status(400).json({ error: "You cannot access this resource" });
        return;
    }
    next();
}));
campaigns.patch("/:id", headers_1.default, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        yield models_1.Campaign.findByIdAndUpdate(req.params.id, req.body);
        const campaign = yield models_1.Campaign.findById(req.params.id);
        res.status(200).json(campaign);
    }
    catch (error) {
        res.status(500).json({ error: "Server ran into an error" });
    }
}));
campaigns.delete("/:id", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const campaign = yield models_1.Campaign.findById(req.params.id);
        yield campaign.delete();
        res.status(200).json({ message: "Campaign deleted" });
    }
    catch (e) {
        res.status(500).json({ error: "Server ran into an error" });
    }
}));
exports.default = campaigns;
//# sourceMappingURL=campaigns.js.map