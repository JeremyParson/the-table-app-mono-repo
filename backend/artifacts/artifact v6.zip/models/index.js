"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.User = exports.Handout = exports.Character = exports.Campaign = void 0;
require("dotenv").config();
const mongoose_1 = __importDefault(require("mongoose"));
const campaign_1 = __importDefault(require("./campaign"));
const character_1 = __importDefault(require("./character"));
const handout_1 = __importDefault(require("./handout"));
const user_1 = __importDefault(require("./user"));
mongoose_1.default.connect(process.env.MONGO_URI).then((_v) => {
    console.log(`Connected to mongoDB`);
});
const Campaign = mongoose_1.default.model('Campaign', campaign_1.default);
exports.Campaign = Campaign;
const Character = mongoose_1.default.model('Character', character_1.default);
exports.Character = Character;
const Handout = mongoose_1.default.model('Handout', handout_1.default);
exports.Handout = Handout;
const User = mongoose_1.default.model('User', user_1.default);
exports.User = User;
//# sourceMappingURL=index.js.map