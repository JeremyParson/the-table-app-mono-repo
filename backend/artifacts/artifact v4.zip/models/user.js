"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const UserSchema = new mongoose_1.Schema({
    username: String,
    email: String,
    passwordDigest: { type: String },
    dateCreated: { type: Date, default: Date.now },
    role: {
        type: String,
        enum: ["admin", "user"],
        required: true,
    },
}, { toJSON: { virtuals: true } });
UserSchema.virtual("campaigns", {
    ref: "Campaign",
    localField: "_id",
    foreignField: "players",
});
UserSchema.virtual("characters", {
    ref: "Character",
    localField: "_id",
    foreignField: "player",
});
exports.default = UserSchema;
//# sourceMappingURL=user.js.map