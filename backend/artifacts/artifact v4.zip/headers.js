"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const headers = (req, res, next) => {
    console.log('headers');
    res.setHeader("Access-Control-Allow-Origin", "http://localhost:3000");
    res.setHeader("Access-Control-Allow-Methods", 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    next();
};
exports.default = headers;
//# sourceMappingURL=headers.js.map