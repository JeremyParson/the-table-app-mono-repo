"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const mongoose_1 = __importDefault(require("mongoose"));
const models_1 = require("../models");
const characters = (0, express_1.Router)();
characters.get("/:id", (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    next();
}));
characters.get("/", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const character = yield models_1.Character.find();
        res.status(200).send(character);
    }
    catch (error) {
        res.status(500).send({ error: "Server ran into an error" });
    }
}));
characters.get("/:id", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const character = yield models_1.Character.findById(req.params.id);
        res.status(200).send(character);
    }
    catch (error) {
        res.status(500).send({ error: "Server ran into an error" });
    }
}));
characters.use((req, res, next) => {
    if (!req.currentUser) {
        res.status(400).send({ error: "You must be logged in" });
        return;
    }
    next();
});
characters.post("/", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const character = yield models_1.Character.create(Object.assign(Object.assign({}, req.body), { creator: req.currentUser._id, player: req.currentUser._id }));
        res.status(201).send(character);
    }
    catch (error) {
        console.log(error.message);
        res.status(500).send({ error: "Server ran into an error" });
    }
}));
characters.post("/:id", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const campaign = yield models_1.Campaign.findById(req.params.id);
        if (!campaign)
            return res.status(400).send({ error: "The campaign does not exist" });
        let isPlayer = false;
        for (let player of campaign.players) {
            isPlayer = player.equals(req.currentUser._id);
            if (isPlayer)
                break;
        }
        if (!isPlayer)
            return res.status(400).send({ error: "You cannot access this resource" });
        const character = yield models_1.Character.create(Object.assign(Object.assign({}, req.body), { creator: req.currentUser._id, player: req.currentUser._id, campaign: campaign._id }));
        res.status(201).send(character);
    }
    catch (error) {
        console.log(error.message);
        res.status(500).send({ error: "Server ran into an error" });
    }
}));
characters.use("/:id", (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    const character = yield models_1.Character.findById(req.params.id);
    if (!character)
        return res.json({ message: 'You cannot access this resource' });
    const isCreator = req.currentUser._id.equals(character.creator);
    const isOwner = req.currentUser._id.equals(character.player);
    if (!(isOwner || isCreator)) {
        res.status(400).send({ error: "You cannot access this resource" });
        return;
    }
    next();
}));
characters.delete("/:id", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        yield models_1.Character.findByIdAndDelete(req.params.id);
        res.status(200).send({ message: "character deleted" });
    }
    catch (error) {
        res.status(500).send({ error: "Server ran into an error" });
    }
}));
characters.patch("/:id", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        yield models_1.Character.findByIdAndUpdate(req.params.id, req.body);
        const character = yield models_1.Character.findById(req.params.id);
        res.status(200).send(character);
    }
    catch (error) {
        res.status(500).send({ error: "Server ran into an error" });
    }
}));
characters.copy("/:id", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        models_1.Character.findById(req.params.id).exec((err, doc) => {
            doc._id = new mongoose_1.default.Types.ObjectId();
            doc.isNew = true;
            doc.save();
        });
        res.status(200).send({ message: "ok" });
    }
    catch (error) {
        res.status(500).send({ error: "Server ran into an error" });
    }
}));
exports.default = characters;
//# sourceMappingURL=characters.js.map