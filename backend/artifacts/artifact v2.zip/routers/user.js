"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const models_1 = require("../models");
const mongoose_1 = require("mongoose");
const bcrypt = __importStar(require("bcrypt"));
const router = (0, express_1.Router)();
router.get("/:id", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const user = yield models_1.User.findById(req.params.id);
        const { username } = user;
        res.json({ username }).status(200);
    }
    catch (err) {
        res.status(500);
    }
}));
router.get("/", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        if (!req.currentUser || req.currentUser.role !== "admin") {
            return res
                .status(404)
                .json({ message: "Only admins can access this route." });
        }
        const users = yield models_1.User.find();
        res.json(users).status(200);
    }
    catch (err) {
        res.status(500);
    }
}));
router.post("/", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const passwordDigest = bcrypt.hashSync(req.body.password, 10);
        const user = new models_1.User(Object.assign(Object.assign({}, req.body), { passwordDigest, role: "user" }));
        user.save();
        res.json(user).status(200);
        console.log("Account created");
    }
    catch (err) {
        if (err instanceof mongoose_1.Error.ValidationError) {
            res.json({ message: "validation failed" }).status(400);
        }
        res.status(500).json({ message: "The server ran into an error." });
        console.log("Account creation failed");
    }
}));
router.use((req, res, next) => {
    if (!req.currentUser) {
        res.status(400).send({ error: "You must be logged in" });
        return;
    }
    next();
});
router.use("/:id", (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    if (req.currentUser.role != 'admin') {
        res.status(400).send({ error: "You cannot access this resource" });
        return;
    }
    next();
}));
router.delete('/:id', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        yield models_1.User.findByIdAndDelete(req.params.id);
        res.json({ message: 'User deleted' }).status(200);
    }
    catch (err) {
        res.json({ message: "The server ran into an error" }).status(400);
    }
}));
exports.default = router;
//# sourceMappingURL=user.js.map