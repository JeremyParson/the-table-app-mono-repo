"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("dotenv").config();
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const method_override_1 = __importDefault(require("method-override"));
const campaigns_1 = __importDefault(require("./routers/campaigns"));
const characters_1 = __importDefault(require("./routers/characters"));
const handouts_1 = __importDefault(require("./routers/handouts"));
const user_1 = __importDefault(require("./routers/user"));
const authentication_1 = __importDefault(require("./routers/authentication"));
const socket_io_1 = __importDefault(require("./socket.io"));
const path_1 = __importDefault(require("path"));
const app = (0, express_1.default)();
(0, socket_io_1.default)(app, process.env.SOCKET_PORT);
app.use(express_1.default.urlencoded({
    extended: true,
}));
let prefix = '';
app.use((0, method_override_1.default)("_method"));
app.use((0, cors_1.default)());
app.all("*", (req, res, next) => {
    res.setHeader("Access-Control-Allow-Headers", "*");
    res.setHeader("Access-Control-Allow-Origin", `http://localhost:3000`);
    res.setHeader("Access-Control-Allow-Methods", 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    next();
});
if (process.env.NODE_ENV === "production") {
    app.use(express_1.default.static(path_1.default.join(__dirname, 'build')));
    prefix = '/api';
}
const defineCurrentUser_1 = __importDefault(require("./middleware/defineCurrentUser"));
app.use(defineCurrentUser_1.default);
const routeLog_1 = __importDefault(require("./middleware/routeLog"));
app.use(routeLog_1.default);
app.use(`${prefix}/campaigns`, campaigns_1.default);
app.use(`${prefix}/characters`, characters_1.default);
app.use(`${prefix}/handouts`, handouts_1.default);
app.use(`${prefix}/auth`, authentication_1.default);
app.use(`${prefix}/user`, user_1.default);
app.listen(process.env.PORT, () => {
    console.log(`Server started on port ${process.env.PORT}`);
});
//# sourceMappingURL=server.js.map