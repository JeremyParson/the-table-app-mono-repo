"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const socket_io_1 = require("socket.io");
const http_1 = __importDefault(require("http"));
const models_1 = require("./models");
const jwt = require("jsonwebtoken");
function createIoInstance(app, port) {
    const server = http_1.default.createServer(app);
    server.listen(port);
    let io = new socket_io_1.Server(server, {
        cors: {
            origin: "*",
            methods: ["GET", "POST"],
        },
    });
    io.on("connection", (socket) => {
        console.log("a user connected");
        socket.on("disconnecting", (reason) => {
            console.log("a user disconnecting");
            socket.rooms.forEach(room => {
                if (socket.id != room) {
                    socket.leave(room);
                }
            });
        });
        socket.on("disconnect", (reason) => {
            console.log("a user disconnected");
        });
        socket.on("message", (message) => __awaiter(this, void 0, void 0, function* () {
            let content = message.content;
            if (content.charAt(0) == "/") {
                if (content.slice(1, 5).toLowerCase() == "roll") {
                    let roll = content.slice(5, content.length).trim();
                    let [quantity, dice] = roll.split("d");
                    let sum = 0;
                    let rolls = 0;
                    while (rolls != Number(quantity)) {
                        rolls += 1;
                        sum += Math.ceil(Math.random() * Number(dice));
                    }
                    message.content += ` [Rolled : ${sum}]`;
                }
            }
            socket.rooms.forEach(room => {
                console.log(socket.id, room);
                if (socket.id != room) {
                    io.in(room).emit("message", message);
                }
            });
        }));
        socket.on("join_session", (data) => __awaiter(this, void 0, void 0, function* () {
            if (!(yield authentication(data)))
                return console.log("socket join room rejected: ", data.sessionId);
            yield socket.join(data.sessionId);
            console.log("socket user joined room: ", data.sessionId);
            console.log(socket.rooms);
        }));
    });
    return io;
}
exports.default = createIoInstance;
function authentication(data) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const [method, token] = data.token.split(" ");
            if (method == "Bearer") {
                const result = jwt.verify(token, process.env.JWT_SECRET);
                const { id } = result;
                const campaign = yield models_1.Campaign.findById(data.sessionId);
                for (let player_id of campaign.players) {
                    if (player_id.equals(id)) {
                        return true;
                    }
                }
                return false;
            }
        }
        catch (err) {
            return false;
        }
    });
}
//# sourceMappingURL=socket.io.js.map