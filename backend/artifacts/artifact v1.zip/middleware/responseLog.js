"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function routeLog(req, res, next) {
    next();
}
exports.default = routeLog;
//# sourceMappingURL=responseLog.js.map